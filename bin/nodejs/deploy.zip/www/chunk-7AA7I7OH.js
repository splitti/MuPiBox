import{b as a,c as b}from"./chunk-NMYJD6OP.js";import"./chunk-RLXPGMKU.js";export{a as GESTURE_CONTROLLER,b as createGesture};
