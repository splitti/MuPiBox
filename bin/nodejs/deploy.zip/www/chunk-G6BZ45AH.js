import{b as a,c as b}from"./chunk-N7R6TYCM.js";import"./chunk-WIDV5QVQ.js";export{a as GESTURE_CONTROLLER,b as createGesture};
