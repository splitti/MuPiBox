export interface Network {
    ip?: string;
    host?: string;
}
