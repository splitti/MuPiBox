export interface WLAN {
    category: string;
    ssid?: string;
    pw?: string;
}
