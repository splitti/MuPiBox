<?php
 include ('includes/header.php');
?>
<div class="main">
<h2>MuPiBox - Media</h2>
<p>Coming soon...</p>


</div>

<?php
 include ('includes/footer.php');
?>
