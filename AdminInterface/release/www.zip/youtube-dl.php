<?php
	$_SERVER['HTTP_HOST']
	include ('includes/header.php');
	include ('http://' . $_SERVER['HTTP_HOST'] . ':8081');
	include ('includes/footer.php');
?>
