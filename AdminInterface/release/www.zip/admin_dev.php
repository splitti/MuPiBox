<form class="appnitro" method="post" action="admin.php" id="form"enctype="multipart/form-da>
        <td>Stable</td>
        <td><?php print $dataonline["release"]["stable"][count($dataonline["release"]["stable"])-1]["vers>
        <td><?php print $dataonline["release"]["stable"][count($dataonline["release"]["stable"])-1]["rele>
        <td>
        <input type="hidden" name="update_url" value="<?php print $dataonline["release"]["stable"][count(>
        <input type="hidden" name="update_env" value="stable" />
        <input type="hidden" name="update_version" value="<?php print $dataonline["release"]["stable"][co>
        <input id="saveForm" class="button_text" type="submit" name="mupibox_update" value="Update to ver>
        </td>
       </form>