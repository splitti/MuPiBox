
<?php
	include ('includes/header.php');
?>
<div class="main">
<h2>System Information</h2>
<p>bla blubbn</p>
</div>

<?php
	include ('includes/footer.html');
?>